#Figure

plot.binomial.distribution(10,0.5)
