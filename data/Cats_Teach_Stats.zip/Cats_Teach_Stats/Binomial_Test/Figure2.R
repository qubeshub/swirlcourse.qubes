#Figure 2

plot.binomial.distribution(100,0.5)