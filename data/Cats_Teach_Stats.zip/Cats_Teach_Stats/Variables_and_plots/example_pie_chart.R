# Example pie chart
slices <- c(10,2)
lbls <- c("sardines","trout")
pie(slices, labels = lbls, main="Pie chart of fish eaten")
